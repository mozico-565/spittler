"""Convert the official RealESRGAN_x4plus.pth to this application's RGB NCHW ONNX graph.

Run after cloning https://github.com/xinntao/Real-ESRGAN and installing its requirements.
Examples in README.md. This script does not download weights or replace their license.
"""
import argparse
import torch
from basicsr.archs.rrdbnet_arch import RRDBNet

parser = argparse.ArgumentParser()
parser.add_argument("weights", help="Path to official RealESRGAN_x4plus.pth")
parser.add_argument("output", help="Path to app/src/main/assets/RealESRGAN_x4plus.onnx")
args = parser.parse_args()

network = RRDBNet(num_in_ch=3, num_out_ch=3, num_feat=64, num_block=23, num_grow_ch=32, scale=4)
checkpoint = torch.load(args.weights, map_location="cpu", weights_only=False)
network.load_state_dict(checkpoint.get("params_ema", checkpoint.get("params", checkpoint)))
network.eval()
with torch.no_grad():
    torch.onnx.export(
        network,
        torch.zeros(1, 3, 256, 256),
        args.output,
        input_names=["input"], output_names=["output"],
        dynamic_axes={"input": {2: "height", 3: "width"}, "output": {2: "height4", 3: "width4"}},
        opset_version=17,
        dynamo=False,
    )
print("Wrote", args.output)
