package com.booksplitter.image

import android.graphics.Bitmap
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import java.nio.FloatBuffer
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.sin

interface ImageUpscaler : AutoCloseable {
    val available: Boolean
    /** Returns a new bitmap. Input ownership stays with the caller. */
    fun upscale(tile: Bitmap): Bitmap
    override fun close() {}
}

/** An optional, locally loaded RealESRGAN_x4plus ONNX graph: [1,3,H,W] RGB float input/output. */
class RealEsrganOnnx(context: Context) : ImageUpscaler {
    private val env:OrtEnvironment? = try { OrtEnvironment.getEnvironment() } catch (_:LinkageError) { null }
    private val session: OrtSession? = try {
        context.assets.open("RealESRGAN_x4plus.onnx").use { input ->
            env?.createSession(input.readBytes(), OrtSession.SessionOptions().apply { setIntraOpNumThreads(2) })
        }
    } catch (_: Exception) { null } catch (_: LinkageError) { null }
    override val available get() = session != null

    override fun upscale(tile: Bitmap): Bitmap {
        val s = session ?: error("model missing")
        val environment = env ?: error("runtime missing")
        val w = tile.width; val h = tile.height; val n = w * h
        val pixels = IntArray(n); tile.getPixels(pixels, 0, w, 0, 0, w, h)
        val rgb = FloatArray(3 * n)
        for (i in 0 until n) {
            rgb[i] = ((pixels[i] ushr 16) and 255) / 255f
            rgb[n + i] = ((pixels[i] ushr 8) and 255) / 255f
            rgb[2*n + i] = (pixels[i] and 255) / 255f
        }
        OnnxTensor.createTensor(environment, FloatBuffer.wrap(rgb), longArrayOf(1,3,h.toLong(),w.toLong())).use { tensor ->
            s.run(mapOf(s.inputNames.first() to tensor)).use { result ->
                val out = result[0] as OnnxTensor
                val shape = out.info.shape
                require(shape.size == 4 && shape[0] == 1L && shape[1] == 3L && shape[2] == h*4L && shape[3] == w*4L)
                val ow = w * 4; val oh = h * 4; val count = ow * oh
                val data = out.floatBuffer
                val converted = IntArray(count)
                for (i in 0 until count) {
                    val r = (data.get(i).coerceIn(0f,1f)*255f + 0.5f).toInt()
                    val g = (data.get(count+i).coerceIn(0f,1f)*255f + 0.5f).toInt()
                    val b = (data.get(2*count+i).coerceIn(0f,1f)*255f + 0.5f).toInt()
                    converted[i] = -0x1000000 or (r shl 16) or (g shl 8) or b
                }
                return Bitmap.createBitmap(converted, ow, oh, Bitmap.Config.ARGB_8888)
            }
        }
    }
    override fun close() { session?.close() }
}

/** Lanczos3, area aware for reductions, premultiplied by an opaque paper background. */
object Lanczos {
    private data class Tap(val indices: IntArray, val weights: DoubleArray)
    private fun kernel(x: Double): Double {
        val v = abs(x)
        if (v < 1e-8) return 1.0
        if (v >= 3) return 0.0
        return (3 * sin(PI*v) * sin(PI*v/3)) / (PI*PI*v*v)
    }
    private fun taps(input: Int, output: Int): Array<Tap> = Array(output) { j ->
        val scale = input.toDouble() / output
        val span = maxOf(1.0, scale)
        val center = (j + .5)*scale - .5
        val start = floor(center-3*span).toInt(); val end = ceil(center+3*span).toInt()
        val map = linkedMapOf<Int,Double>()
        for (k in start..end) {
            val key = k.coerceIn(0,input-1)
            map[key] = (map[key] ?: 0.0) + kernel((k-center)/span)
        }
        val sum = map.values.sum()
        Tap(map.keys.toIntArray(), map.values.map { if (sum == 0.0) 0.0 else it/sum }.toDoubleArray())
    }
    fun resize(source: Bitmap, width: Int, height: Int): Bitmap {
        require(width > 0 && height > 0)
        val sw = source.width; val sh = source.height
        if (sw == width && sh == height) return source.copy(Bitmap.Config.ARGB_8888, false)
        val src = IntArray(sw*sh); source.getPixels(src,0,sw,0,0,sw,sh)
        val horizontal = FloatArray(width*sh*3)
        val xs = taps(sw,width)
        for (y in 0 until sh) for (x in 0 until width) {
            val t=xs[x]; var r=0.0; var g=0.0; var b=0.0
            for (i in t.indices.indices) {
                val c=src[y*sw+t.indices[i]]; val w=t.weights[i]
                r += ((c ushr 16) and 255)*w; g += ((c ushr 8) and 255)*w; b += (c and 255)*w
            }
            val p=(y*width+x)*3; horizontal[p]=r.toFloat(); horizontal[p+1]=g.toFloat(); horizontal[p+2]=b.toFloat()
        }
        val ys=taps(sh,height); val dst=IntArray(width*height)
        for (y in 0 until height) for (x in 0 until width) {
            val t=ys[y]; var r=0.0; var g=0.0; var b=0.0
            for (i in t.indices.indices) {
                val p=(t.indices[i]*width+x)*3; val w=t.weights[i]
                r += horizontal[p]*w; g += horizontal[p+1]*w; b += horizontal[p+2]*w
            }
            dst[y*width+x] = -0x1000000 or (r.toInt().coerceIn(0,255) shl 16) or (g.toInt().coerceIn(0,255) shl 8) or b.toInt().coerceIn(0,255)
        }
        return Bitmap.createBitmap(dst,width,height,Bitmap.Config.ARGB_8888)
    }
    fun mix(ai: Bitmap, original: Bitmap, strength: Float): Bitmap {
        val basic=resize(original,ai.width,ai.height)
        val count=ai.width*ai.height; val a=IntArray(count); val b=IntArray(count)
        ai.getPixels(a,0,ai.width,0,0,ai.width,ai.height)
        basic.getPixels(b,0,ai.width,0,0,ai.width,ai.height)
        for (i in 0 until count) {
            val r=((a[i] ushr 16 and 255)*strength+(b[i] ushr 16 and 255)*(1-strength)).toInt()
            val g=((a[i] ushr 8 and 255)*strength+(b[i] ushr 8 and 255)*(1-strength)).toInt()
            val blue=((a[i] and 255)*strength+(b[i] and 255)*(1-strength)).toInt()
            a[i]=-0x1000000 or (r shl 16) or (g shl 8) or blue
        }
        basic.recycle()
        return Bitmap.createBitmap(a,ai.width,ai.height,Bitmap.Config.ARGB_8888)
    }
}
