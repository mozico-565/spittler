package com.booksplitter.image

import kotlin.math.roundToInt

object Geometry {
    const val WIDTH = 3840
    fun height(width: Int, height: Int, targetWidth: Int = WIDTH): Int {
        require(width > 0 && height > 0 && targetWidth > 0)
        return (height.toDouble() * targetWidth / width).roundToInt().coerceAtLeast(1)
    }
    fun range(height: Int, count: Int, index: Int): IntRange {
        require(height >= count && count in 2..20 && index in 0 until count)
        val unit = height / count
        val start = unit * index
        return start until (if (index == count - 1) height else start + unit)
    }
}
