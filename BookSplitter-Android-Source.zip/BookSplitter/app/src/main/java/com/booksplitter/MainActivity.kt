package com.booksplitter

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.exifinterface.media.ExifInterface
import com.booksplitter.image.Part
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity:ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            MaterialTheme(colorScheme=lightColorScheme(primary=Color(0xFF215847),secondary=Color(0xFF547F70))) {
                BookApp()
            }
        } }
    }
}

private suspend fun thumbnail(file:File,size:Int=1000):Bitmap? = withContext(Dispatchers.IO) {
    try {
        val opts=BitmapFactory.Options().apply { inJustDecodeBounds=true }
        BitmapFactory.decodeFile(file.path,opts)
        var sample=1
        while(opts.outWidth/sample>size*2 || opts.outHeight/sample>size*3) sample*=2
        BitmapFactory.decodeFile(file.path,BitmapFactory.Options().apply { inSampleSize=sample })
    } catch (_:Exception) { null }
}
private suspend fun thumbnail(uri:Uri,context:android.content.Context):Bitmap? = withContext(Dispatchers.IO) {
    try {
        val options=BitmapFactory.Options().apply { inJustDecodeBounds=true }
        context.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it,null,options) }
        var sample=1
        while(options.outWidth/sample>1200 || options.outHeight/sample>2200) sample*=2
        val bitmap=context.contentResolver.openInputStream(uri)!!.use {
            BitmapFactory.decodeStream(it,null,BitmapFactory.Options().apply { inSampleSize=sample })
        } ?: return@withContext null
        val orientation=context.contentResolver.openInputStream(uri)!!.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION,1) }
        val matrix=Matrix()
        when(orientation) {
            2 -> matrix.postScale(-1f,1f)
            3 -> matrix.postRotate(180f)
            4 -> matrix.postScale(1f,-1f)
            5 -> { matrix.postRotate(90f); matrix.postScale(1f,-1f) }
            6 -> matrix.postRotate(90f)
            7 -> { matrix.postRotate(90f); matrix.postScale(-1f,1f) }
            8 -> matrix.postRotate(270f)
        }
        if(orientation==1) bitmap else Bitmap.createBitmap(bitmap,0,0,bitmap.width,bitmap.height,matrix,true).also { bitmap.recycle() }
    } catch (_:Exception) { null }
}

@Composable private fun BookApp(vm:BookViewModel=viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context=LocalContext.current
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { it?.let(vm::pick) }
    val storage=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if(granted) vm.saveAll() else vm.error("يحتاج الحفظ إلى صلاحية التخزين على Android 9 وأقدم.")
    }
    var selected by remember { mutableStateOf<Part?>(null) }
    var settings by remember { mutableStateOf(false) }
    var askCount by remember(state.image) { mutableStateOf(false) }
    LaunchedEffect(state.dimensions) { if(state.dimensions!=null && state.phase==Phase.Picked) askCount=true }

    Scaffold(topBar={ Surface(shadowElevation=2.dp) {
        Row(Modifier.fillMaxWidth().height(64.dp).padding(horizontal=20.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween) {
            Text("Book Splitter",style=MaterialTheme.typography.titleLarge)
            TextButton(onClick={settings=true}) { Text("الإعدادات") }
        }
    } }) { padding ->
        val body=Modifier.fillMaxSize().padding(padding).padding(horizontal=20.dp, vertical=16.dp)
        val scroll=rememberScrollState()
        Column(if(state.phase is Phase.Picked || state.phase is Phase.Processing || state.phase is Phase.Error) body.verticalScroll(scroll) else body,verticalArrangement=Arrangement.spacedBy(16.dp)) {
            val phase=state.phase
            if(phase is Phase.Idle || state.image==null) {
                Spacer(Modifier.weight(1f))
                Text("قسّم صفحة الكتاب إلى صور واضحة بالترتيب",style=MaterialTheme.typography.headlineSmall)
                Button(onClick={picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))},modifier=Modifier.fillMaxWidth().height(58.dp)) { Text("اختر صورة الكتاب") }
                Spacer(Modifier.weight(1f))
            } else if(phase is Phase.Done) {
                Text("الأجزاء الناتجة (${phase.results.size})",style=MaterialTheme.typography.titleLarge)
                state.notice?.let { Text(it,color=MaterialTheme.colorScheme.primary) }
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Button(onClick={if(Build.VERSION.SDK_INT>=29) vm.saveAll() else storage.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)},enabled=!state.busySaving,modifier=Modifier.weight(1f)) { Text(if(state.busySaving) "جاري الحفظ…" else "حفظ الكل في المعرض") }
                    OutlinedButton(onClick={vm.share()?.let { context.startActivity(Intent.createChooser(it,"مشاركة الأجزاء")) }}) { Text("مشاركة") }
                }
                OutlinedButton(onClick={picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))}) { Text("صورة أخرى") }
                LazyVerticalGrid(columns=GridCells.Fixed(2),verticalArrangement=Arrangement.spacedBy(10.dp),horizontalArrangement=Arrangement.spacedBy(10.dp),modifier=Modifier.fillMaxSize()) {
                    items(phase.results,key={it.number}) { item ->
                        val thumb by produceState<Bitmap?>(null,item.enhanced) { value=thumbnail(item.enhanced,500) }
                        Card(Modifier.fillMaxWidth().clickable { selected=item }) {
                            Column(Modifier.padding(8.dp)) {
                                thumb?.let { Image(it.asImageBitmap(),"الجزء ${item.number}",Modifier.fillMaxWidth().height(150.dp),contentScale=ContentScale.Fit) }
                                Text("الجزء ${item.number} · اضغط للمقارنة")
                            }
                        }
                    }
                }
            } else {
                val dims=state.dimensions
                Text("معاينة الصورة",style=MaterialTheme.typography.titleLarge)
                val bmp by produceState<Bitmap?>(null,state.image) { value=state.image?.let { thumbnail(it,context) } }
                val canvasHeight=if(dims!=null) (340f*dims.height/dims.width).coerceIn(180f,470f).dp else 340.dp
                Box(Modifier.fillMaxWidth().height(canvasHeight).clip(RoundedCornerShape(16.dp)),contentAlignment=Alignment.Center) {
                    bmp?.let { Image(it.asImageBitmap(),"معاينة صفحة الكتاب",Modifier.fillMaxSize(),contentScale=ContentScale.Fit) }
                    if(dims!=null && bmp!=null) {
                        Canvas(Modifier.fillMaxSize()) {
                            val scale=min(size.width/dims.width,size.height/dims.height)
                            val top=(size.height-dims.height*scale)/2f
                            val left=(size.width-dims.width*scale)/2f
                            val n=state.count.toIntOrNull() ?: 4
                            for(i in 1 until n.coerceIn(2,20)) {
                                val y=top+((dims.height/n)*i)*scale
                                drawLine(Color(0xFF00A985),Offset(left,y),Offset(left+dims.width*scale,y),strokeWidth=2.dp.toPx())
                            }
                        }
                    }
                }
                OutlinedTextField(value=state.count,onValueChange=vm::count,label={Text("كم تقسيمة تريد؟")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),isError=(state.count.toIntOrNull() ?: 0) !in 2..20,modifier=Modifier.fillMaxWidth())
                if((state.count.toIntOrNull() ?: 0) !in 2..20) Text("اختر عددًا من 2 إلى 20",color=MaterialTheme.colorScheme.error)
                state.notice?.let { Text(it,color=MaterialTheme.colorScheme.primary) }
                when(phase) {
                    is Phase.Processing -> {
                        LinearProgressIndicator(progress={ (phase.section-1+(phase.tile.toFloat()/phase.tiles))/phase.sections },modifier=Modifier.fillMaxWidth())
                        Text("جاري معالجة ${phase.section} من ${phase.sections} · المربع ${phase.tile} من ${phase.tiles}")
                        OutlinedButton(onClick=vm::cancel) { Text("إلغاء") }
                    }
                    else -> {
                        Button(onClick=vm::split,enabled=dims!=null,modifier=Modifier.fillMaxWidth()) { Text("قسّم الصورة") }
                        OutlinedButton(onClick={picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))}) { Text("تغيير الصورة") }
                        if(phase is Phase.Error) Text(phase.message,color=MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
    if(askCount && state.phase==Phase.Picked) AlertDialog(onDismissRequest={askCount=false},title={Text("كم تقسيمة تريد؟")},text={Text("القيمة الافتراضية 4. يمكنك تغييرها قبل البدء.")},confirmButton={TextButton(onClick={askCount=false}) {Text("تمام")}})
    if(settings) AlertDialog(onDismissRequest={settings=false},title={Text("جودة التكبير")},text={
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text("نموذج Real-ESRGAN اختياري. إن غاب يُستخدم Lanczos محليًا.")
            listOf("وفيّ للنص (موصى به)" to .7f,"أقوى وضوحاً" to 1f).forEach { (label,value) ->
                Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.clickable { vm.strength(value) }) {
                    RadioButton(selected=state.strength==value,onClick={vm.strength(value)}); Text(label)
                }
            }
            Text("قوة التحسين: ${(state.strength*100).roundToInt()}%")
            Slider(value=state.strength,onValueChange=vm::strength)
        }
    },confirmButton={TextButton(onClick={settings=false}) {Text("تم")}})
    selected?.let { Comparison(it,onDismiss={selected=null}) }
}

@Composable private fun Comparison(part:Part,onDismiss:()->Unit) {
    val before by produceState<Bitmap?>(null,part.original) { value=thumbnail(part.original,2000) }
    val after by produceState<Bitmap?>(null,part.enhanced) { value=thumbnail(part.enhanced,2000) }
    var fraction by remember(part) { mutableFloatStateOf(.5f) }
    var zoom by remember(part) { mutableFloatStateOf(1f) }
    var shift by remember(part) { mutableStateOf(Offset.Zero) }
    DialogWrapper(onDismiss) {
        Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                Text("الجزء ${part.number} · قبل / بعد",style=MaterialTheme.typography.titleMedium)
                TextButton(onClick=onDismiss) {Text("إغلاق")}
            }
            Text("اسحب المؤشر وكبّر بإصبعين للتحقق من الحروف. نسخة «قبل» للمعاينة بدقة أقل.")
            Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(12.dp)).pointerInput(part) {
                detectTransformGestures { _, pan, z, _ -> zoom=(zoom*z).coerceIn(1f,8f); shift+=pan }
            },contentAlignment=Alignment.Center) {
                val move=Modifier.fillMaxSize().graphicsLayer(scaleX=zoom,scaleY=zoom,translationX=shift.x,translationY=shift.y)
                before?.let { Image(it.asImageBitmap(),"قبل",move,contentScale=ContentScale.Fit) }
                after?.let { Image(it.asImageBitmap(),"بعد",move.drawWithContent {
                    clipRect(0f,0f,size.width*fraction,size.height) { drawContent() }
                },contentScale=ContentScale.Fit) }
            }
            Text("بعد ${ (fraction*100).roundToInt() }%")
            Slider(value=fraction,onValueChange={fraction=it})
            Text("التغيير البصري يحتاج مراجعة منك قبل حفظ الأجزاء.")
        }
    }
}

@Composable private fun DialogWrapper(onDismiss:()->Unit,content:@Composable ()->Unit) {
    androidx.compose.ui.window.Dialog(onDismissRequest=onDismiss,properties=androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth=false)) {
        Surface(Modifier.fillMaxSize(),color=MaterialTheme.colorScheme.surface,content=content)
    }
}
