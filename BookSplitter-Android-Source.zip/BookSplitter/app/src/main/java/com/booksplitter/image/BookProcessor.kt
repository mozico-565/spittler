package com.booksplitter.image

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.io.FileOutputStream
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class Part(val number: Int, val enhanced: File, val original: File)
data class Dimensions(val width: Int, val height: Int)

class BookProcessor(private val context: Context) {
    private fun sourceFile(uri: Uri): File {
        val file = File(context.cacheDir,"book_source_${System.nanoTime()}")
        try {
            context.contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use(input::copyTo) }
                ?: error("unreadable")
            return file
        } catch (e: Exception) { file.delete(); throw e }
    }
    fun dimensions(uri: Uri): Dimensions = context.contentResolver.openInputStream(uri)!!.use { stream ->
        val bounds=BitmapFactory.Options().apply { inJustDecodeBounds=true }
        BitmapFactory.decodeStream(stream,null,bounds)
        require(bounds.outWidth>0 && bounds.outHeight>0)
        val exif=context.contentResolver.openInputStream(uri)!!.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION,1) }
        if (exif in 5..8) Dimensions(bounds.outHeight,bounds.outWidth) else Dimensions(bounds.outWidth,bounds.outHeight)
    }
    private fun toRaw(x:Int,y:Int,w:Int,h:Int,o:Int):Pair<Int,Int> = when(o) {
        2 -> w-x to y
        3 -> w-x to h-y
        4 -> x to h-y
        5 -> y to x
        6 -> y to h-x
        7 -> w-y to h-x
        8 -> w-y to x
        else -> x to y
    }
    private fun toOriented(x:Int,y:Int,w:Int,h:Int,o:Int):Pair<Int,Int> = when(o) {
        2 -> w-x to y
        3 -> w-x to h-y
        4 -> x to h-y
        5 -> y to x
        6 -> h-y to x
        7 -> h-y to w-x
        8 -> y to w-x
        else -> x to y
    }
    @Suppress("DEPRECATION")
    private fun tile(decoder: BitmapRegionDecoder, x:Int,y:Int,width:Int,height:Int,w:Int,h:Int,o:Int,sample:Int=1):Bitmap {
        val corners=listOf(toRaw(x,y,w,h,o),toRaw(x+width,y,w,h,o),toRaw(x,y+height,w,h,o),toRaw(x+width,y+height,w,h,o))
        val left=corners.minOf { it.first }; val top=corners.minOf { it.second }
        val rect=Rect(left,top,corners.maxOf { it.first },corners.maxOf { it.second })
        val raw=decoder.decodeRegion(rect,BitmapFactory.Options().apply { inPreferredConfig=Bitmap.Config.ARGB_8888; inSampleSize=sample })
            ?: error("decode failed")
        val points=listOf(0 to 0,raw.width to 0,0 to raw.height)
        val src=FloatArray(6); val dest=FloatArray(6)
        points.forEachIndexed { i, p ->
            src[2*i]=p.first.toFloat(); src[2*i+1]=p.second.toFloat()
            val mapped=toOriented(left+if(i==1)rect.width() else 0,top+if(i==2)rect.height() else 0,w,h,o)
            dest[2*i]=(mapped.first-x).toFloat()/sample; dest[2*i+1]=(mapped.second-y).toFloat()/sample
        }
        val matrix=Matrix(); check(matrix.setPolyToPoly(src,0,dest,0,3))
        val output=Bitmap.createBitmap(max(1,width/sample),max(1,height/sample),Bitmap.Config.ARGB_8888)
        Canvas(output).drawBitmap(raw,matrix,Paint(Paint.FILTER_BITMAP_FLAG))
        raw.recycle()
        return output
    }
    private fun png(bitmap:Bitmap,file:File) {
        FileOutputStream(file).use { check(bitmap.compress(Bitmap.CompressFormat.PNG,100,it)) }
    }
    suspend fun process(uri:Uri,count:Int,strength:Float,progress:(Int,Int,Int,Int)->Unit,notice:(String)->Unit):List<Part> {
        require(count in 2..20)
        val source=sourceFile(uri)
        val files=mutableListOf<File>(); val completed=mutableListOf<Part>()
        try {
            val bounds=BitmapFactory.Options().apply { inJustDecodeBounds=true }
            BitmapFactory.decodeFile(source.path,bounds)
            val w=bounds.outWidth; val h=bounds.outHeight
            require(w>0 && h>0)
            val orientation=ExifInterface(source.path).getAttributeInt(ExifInterface.TAG_ORIENTATION,1)
            val ow=if(orientation in 5..8) h else w
            val oh=if(orientation in 5..8) w else h
            require(oh>=count)
            val dir=File(context.cacheDir,"parts").apply { mkdirs() }
            val batch=System.currentTimeMillis()
            val upscaler:ImageUpscaler=RealEsrganOnnx(context)
            if (!upscaler.available && ow<Geometry.WIDTH) notice("النموذج غير مضمّن؛ استُخدم تكبير Lanczos المحلي.")
            try {
                @Suppress("DEPRECATION") val decoder=BitmapRegionDecoder.newInstance(source.path,false)
                try {
                    for (index in 0 until count) {
                        currentCoroutineContext().ensureActive()
                        val range=Geometry.range(oh,count,index); val sh=range.count()
                        val enhanced=File(dir,"${batch}_enhanced_${index+1}.png"); files+=enhanced
                        if(ow>=Geometry.WIDTH) {
                            val coroutine=currentCoroutineContext()
                            FileOutputStream(enhanced).use { stream ->
                                StreamingPng.write(stream,ow,sh) { emit ->
                                    var y=0
                                    val blocks=(sh+63)/64
                                    while(y<sh) {
                                        coroutine.ensureActive()
                                        val rows=min(64,sh-y)
                                        val strip=tile(decoder,0,range.first+y,ow,rows,w,h,orientation)
                                        val pixels=IntArray(ow*rows); strip.getPixels(pixels,0,ow,0,0,ow,rows)
                                        for(row in 0 until rows) emit(pixels.copyOfRange(row*ow,(row+1)*ow))
                                        strip.recycle(); y+=rows
                                        progress(index+1,count,(y+63)/64,blocks)
                                    }
                                }
                            }
                        } else {
                        val outW=if(ow>=Geometry.WIDTH) ow else Geometry.WIDTH
                        val outH=if(ow>=Geometry.WIDTH) sh else Geometry.height(ow,sh)
                        val output=Bitmap.createBitmap(outW,outH,Bitmap.Config.ARGB_8888)
                        val step=224; val tileSize=256
                        val xs=generateSequence(0) { if(it+step<ow) it+step else null }.toList()
                        val ys=generateSequence(0) { if(it+step<sh) it+step else null }.toList()
                        val total=xs.size*ys.size; var tileIndex=0
                        var modelAvailable=upscaler.available && ow<Geometry.WIDTH
                        for (ty in ys) for(tx in xs) {
                            currentCoroutineContext().ensureActive()
                            val tw=min(tileSize,ow-tx); val th=min(tileSize,sh-ty)
                            val input=tile(decoder,tx,range.first+ty,tw,th,w,h,orientation)
                            val dx=(tx.toDouble()*outW/ow).roundToInt()
                            val dy=(ty.toDouble()*outH/sh).roundToInt()
                            val ex=((tx+tw).toDouble()*outW/ow).roundToInt()
                            val ey=((ty+th).toDouble()*outH/sh).roundToInt()
                            var ai:Bitmap?=null
                            if(modelAvailable) try { ai=upscaler.upscale(input) }
                            catch (_: Exception) { modelAvailable=false; notice("تعذّر تشغيل النموذج؛ اكتمل العمل بتكبير Lanczos.") }
                            catch (_: LinkageError) { modelAvailable=false; notice("تعذّر تشغيل النموذج؛ اكتمل العمل بتكبير Lanczos.") }
                            val blended=if(ai!=null) Lanczos.mix(ai,input,strength) else null
                            ai?.recycle()
                            val patch=Lanczos.resize(blended ?: input,ex-dx,ey-dy)
                            blended?.recycle(); input.recycle()
                            val pw=patch.width; val ph=patch.height
                            val incoming=IntArray(pw*ph); patch.getPixels(incoming,0,pw,0,0,pw,ph)
                            val old=IntArray(pw*ph)
                            output.getPixels(old,0,pw,dx,dy,pw,ph)
                            val overlapX=if(tx==0) 0 else (((tx+32).toDouble()*outW/ow).roundToInt()-dx).coerceAtLeast(1)
                            val overlapY=if(ty==0) 0 else (((ty+32).toDouble()*outH/sh).roundToInt()-dy).coerceAtLeast(1)
                            for(py in 0 until ph) for(px in 0 until pw) {
                                val wx=if(tx==0) 1f else (px.toFloat()/overlapX).coerceIn(0f,1f)
                                val wy=if(ty==0) 1f else (py.toFloat()/overlapY).coerceIn(0f,1f)
                                val alpha=min(wx,wy)
                                val at=py*pw+px; val a=incoming[at]; val b=old[at]
                                if(alpha<1f) {
                                    val r=(((a ushr 16 and 255)*alpha)+((b ushr 16 and 255)*(1-alpha))).toInt()
                                    val g=(((a ushr 8 and 255)*alpha)+((b ushr 8 and 255)*(1-alpha))).toInt()
                                    val blue=(((a and 255)*alpha)+((b and 255)*(1-alpha))).toInt()
                                    incoming[at]=-0x1000000 or (r shl 16) or (g shl 8) or blue
                                }
                            }
                            output.setPixels(incoming,0,pw,dx,dy,pw,ph); patch.recycle()
                            progress(index+1,count,++tileIndex,total)
                        }
                        png(output,enhanced); output.recycle()
                        }
                        // Comparison source is a reduced-resolution, unmodified oriented section.
                        var sampleFactor=1
                        while (ow/sampleFactor>1600 || sh/sampleFactor>2400) sampleFactor*=2
                        val preview=tile(decoder,0,range.first,ow,sh,w,h,orientation,sampleFactor)
                        val original=File(dir,"${batch}_original_${index+1}.png"); files+=original
                        png(preview,original); preview.recycle()
                        completed+=Part(index+1,enhanced,original)
                    }
                } finally { decoder.recycle() }
            } finally { upscaler.close() }
            return completed
        } catch(e:Throwable) { files.forEach(File::delete); throw e }
        finally { source.delete() }
    }
}
