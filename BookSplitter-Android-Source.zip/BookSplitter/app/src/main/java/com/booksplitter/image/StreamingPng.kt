package com.booksplitter.image

import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.DeflaterOutputStream

/** Writes opaque RGB PNG scanlines in one zlib stream, without allocating an output bitmap. */
object StreamingPng {
    private fun OutputStream.int32(value:Int) {
        write(value ushr 24); write(value ushr 16); write(value ushr 8); write(value)
    }
    private fun chunk(out:OutputStream,type:String,data:ByteArray) {
        val tag=type.toByteArray(Charsets.US_ASCII)
        out.int32(data.size); out.write(tag); out.write(data)
        val crc=CRC32(); crc.update(tag); crc.update(data)
        out.int32(crc.value.toInt())
    }
    fun write(out:OutputStream,width:Int,height:Int,scanlines:(emit:(IntArray)->Unit)->Unit) {
        require(width>0 && height>0)
        out.write(byteArrayOf(-119,80,78,71,13,10,26,10))
        val header=java.io.ByteArrayOutputStream().apply {
            int32(width); int32(height); write(byteArrayOf(8,2,0,0,0))
        }.toByteArray()
        chunk(out,"IHDR",header)
        val buffer=object:OutputStream() {
            private val bytes=java.io.ByteArrayOutputStream(32768)
            override fun write(b:Int) { bytes.write(b); if(bytes.size()>=32768) flush() }
            override fun write(b:ByteArray,off:Int,len:Int) {
                var pos=off; val end=off+len
                while(pos<end) {
                    val take=minOf(32768-bytes.size(),end-pos)
                    bytes.write(b,pos,take); pos+=take
                    if(bytes.size()>=32768) flush()
                }
            }
            override fun flush() { if(bytes.size()>0) { chunk(out,"IDAT",bytes.toByteArray()); bytes.reset() } }
        }
        var rowCount=0
        DeflaterOutputStream(buffer).use { zip ->
            scanlines { row ->
                check(row.size==width && rowCount++ < height)
                val data=ByteArray(1+width*3)
                for(i in row.indices) {
                    data[1+i*3]=(row[i] ushr 16).toByte()
                    data[2+i*3]=(row[i] ushr 8).toByte()
                    data[3+i*3]=row[i].toByte()
                }
                zip.write(data)
            }
        }
        check(rowCount==height)
        buffer.flush(); chunk(out,"IEND",byteArrayOf())
    }
}
