package com.booksplitter

import android.app.Application
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.booksplitter.image.BookProcessor
import com.booksplitter.image.Dimensions
import com.booksplitter.image.Part
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

sealed interface Phase {
    data object Idle:Phase
    data object Picked:Phase
    data class Processing(val section:Int,val sections:Int,val tile:Int,val tiles:Int):Phase
    data class Done(val results:List<Part>):Phase
    data class Error(val message:String):Phase
}
data class ScreenState(
    val phase:Phase=Phase.Idle,
    val image:Uri?=null,
    val dimensions:Dimensions?=null,
    val count:String="4",
    val strength:Float=.7f,
    val notice:String?=null,
    val busySaving:Boolean=false
)

class BookViewModel(app:Application):AndroidViewModel(app) {
    private val mutable=MutableStateFlow(ScreenState())
    val state=mutable.asStateFlow()
    private var job:Job?=null
    private val processor=BookProcessor(app)
    fun pick(uri:Uri) {
        job?.cancel()
        mutable.value=ScreenState(image=uri,count=mutable.value.count,strength=mutable.value.strength,phase=Phase.Picked)
        viewModelScope.launch {
            try {
                val dims=withContext(Dispatchers.IO) { processor.dimensions(uri) }
                mutable.value=mutable.value.copy(dimensions=dims)
            } catch (_:Exception) { mutable.value=mutable.value.copy(phase=Phase.Error("تعذّر قراءة الصورة. اختر صورة أخرى.")) }
        }
    }
    fun count(value:String) { mutable.value=mutable.value.copy(count=value.filter(Char::isDigit).take(2)) }
    fun strength(value:Float) { mutable.value=mutable.value.copy(strength=value.coerceIn(0f,1f)) }
    fun error(message:String) { mutable.value=mutable.value.copy(phase=Phase.Error(message)) }
    fun clearNotice() { mutable.value=mutable.value.copy(notice=null) }
    fun split() {
        if(job?.isActive==true) return
        val snapshot=mutable.value
        val amount=snapshot.count.toIntOrNull()
        if(amount==null || amount !in 2..20) { error("أدخل عددًا من 2 إلى 20."); return }
        if(snapshot.dimensions==null || snapshot.dimensions.height<amount) { error("الصورة غير مقروءة أو أصغر من عدد التقسيمات."); return }
        val image=snapshot.image ?: return
        job=viewModelScope.launch {
            mutable.value=mutable.value.copy(phase=Phase.Processing(1,amount,0,1),notice=null)
            try {
                val parts=withContext(Dispatchers.Default) {
                    processor.process(image,amount,snapshot.strength,
                        { a,b,c,d -> mutable.value=mutable.value.copy(phase=Phase.Processing(a,b,c,d)) },
                        { message -> mutable.value=mutable.value.copy(notice=message) })
                }
                mutable.value=mutable.value.copy(phase=Phase.Done(parts))
            } catch (_:CancellationException) { mutable.value=mutable.value.copy(phase=Phase.Picked) }
            catch (_:OutOfMemoryError) { error("الذاكرة غير كافية لهذه الصورة. جرّب صورة أصغر أو تقسيمات أكثر.") }
            catch (_:Exception) { error("تعذّر معالجة الصورة. تأكد أنها صورة صالحة وأن مساحة الجهاز كافية.") }
        }
    }
    fun cancel() { job?.cancel() }
    fun saveAll() {
        val parts=(mutable.value.phase as? Phase.Done)?.results ?: return
        if(mutable.value.busySaving) return
        viewModelScope.launch {
            mutable.value=mutable.value.copy(busySaving=true)
            try {
                withContext(Dispatchers.IO) { saveParts(parts) }
                mutable.value=mutable.value.copy(notice="تم حفظ ${parts.size} صور في Pictures/BookSplitter")
            } catch (_:Exception) { mutable.value=mutable.value.copy(notice="فشل حفظ الصور. تأكد من المساحة وصلاحية التخزين.") }
            finally { mutable.value=mutable.value.copy(busySaving=false) }
        }
    }
    private fun saveParts(parts:List<Part>) {
        val resolver=getApplication<Application>().contentResolver
        val created=mutableListOf<Uri>()
        val timestamp=System.currentTimeMillis()
        try {
            parts.forEach { part ->
                val values=ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME,"book_part_${part.number}_$timestamp.png")
                    put(MediaStore.Images.Media.MIME_TYPE,"image/png")
                    if(Build.VERSION.SDK_INT>=29) {
                        put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/BookSplitter")
                        put(MediaStore.Images.Media.IS_PENDING,1)
                    } else {
                        val folder=File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),"BookSplitter")
                        check(folder.exists() || folder.mkdirs())
                        put(MediaStore.Images.Media.DATA,File(folder,"book_part_${part.number}_$timestamp.png").absolutePath)
                    }
                }
                val uri=resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values) ?: error("insert failed")
                created+=uri
                resolver.openOutputStream(uri)?.use { out -> FileInputStream(part.enhanced).use { it.copyTo(out) } } ?: error("stream failed")
                if(Build.VERSION.SDK_INT>=29) resolver.update(uri,ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING,0) },null,null)
            }
        } catch(t:Throwable) { created.forEach { resolver.delete(it,null,null) }; throw t }
    }
    fun share():Intent? {
        val parts=(mutable.value.phase as? Phase.Done)?.results ?: return null
        val app=getApplication<Application>()
        val uris=ArrayList(parts.map { FileProvider.getUriForFile(app,"${app.packageName}.files",it.enhanced) })
        return Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type="image/png"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM,uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            clipData=android.content.ClipData.newUri(app.contentResolver,"Book Splitter",uris.first()).apply {
                uris.drop(1).forEach { addItem(android.content.ClipData.Item(it)) }
            }
        }
    }
}
