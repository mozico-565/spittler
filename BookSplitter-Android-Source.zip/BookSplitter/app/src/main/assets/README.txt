Place the exported RealESRGAN_x4plus.onnx here to enable offline AI upscaling.
Without it, the app uses local Lanczos3 and displays a notice.
