package com.booksplitter.image

import org.junit.Assert.assertEquals
import org.junit.Test

class GeometryTest {
    @Test fun widthAndAspectRatio() {
        val w = 1920; val h = 1080
        val outW = Geometry.WIDTH
        val outH = Geometry.height(w, h)
        assertEquals(3840, outW)
        assertEquals(h.toDouble() / w, outH.toDouble() / outW, 1.0 / outW)
    }
    @Test fun lastGetsRemainder() {
        val ranges = (0..3).map { Geometry.range(1003, 4, it) }
        assertEquals(listOf(250,250,250,253), ranges.map { it.count() })
        assertEquals(1002, ranges.last().last)
    }
}
