# Book Splitter

Native Arabic Kotlin/Compose app, min SDK 26, target SDK 37. Select a photo, divide it into 2–20 equal vertical sections, preview the ordered results and export PNGs to `Pictures/BookSplitter`. The last section receives the remainder. A `BitmapRegionDecoder` reads 256 px tiles with 32 px overlap; EXIF orientation is applied before sectioning. Lanczos3 is the always available offline path.

## Build on a phone via GitHub

1. Create a GitHub repository and upload the **contents** of this folder, including `.github/workflows/android.yml`.
2. Open **Actions → Android APK → Run workflow**; wait for the green build.
3. Open that run's **Artifacts → BookSplitter-debug-APK**, unzip it, then install `app-debug.apk` on Android 8 or later.

Alternatively open the folder in Android Studio (JDK 17, Android SDK 37), sync Gradle 9.5 and run `./gradlew :app:testDebugUnitTest :app:assembleDebug`. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

**Signed release APK:** Android Studio → Build → Generate Signed App Bundle / APK → APK → Create new keystore → release → Finish. Keep the keystore private. `assembleRelease` without signing produces an unsigned APK and cannot be installed normally.

## Enable the local AI model

The archive **does not include model weights**. Until they are added, the app works offline using Lanczos3 and shows an Arabic notice. No network permission, background model download or API keys are used. Adding an arbitrary `.pth` file does not enable AI: the on-device runtime expects an exported ONNX graph. This implementation uses ONNX Runtime Mobile CPU (an acceptable local alternative to NCNN/Vulkan), so it also works on devices without Vulkan.

The upstream [Real-ESRGAN repository](https://github.com/xinntao/Real-ESRGAN) distributes the general x4plus weights; check its model terms before redistribution. On a computer/Colab:

```bash
git clone https://github.com/xinntao/Real-ESRGAN.git
cd Real-ESRGAN
python -m pip install -r requirements.txt
python -m pip install -e . onnx
# Download the official RealESRGAN_x4plus.pth from the upstream model zoo.
python /path/to/BookSplitter/tools/export_model.py /path/to/RealESRGAN_x4plus.pth /path/to/BookSplitter/app/src/main/assets/RealESRGAN_x4plus.onnx
```

Rebuild the APK afterward; the graph is bundled for offline use. Expected interface: float32 RGB in `[0,1]`, NCHW `[1,3,H,W]`, x4 RGB output `[1,3,4H,4W]`. Test the exported model on one page before relying on it. The app detects a failed or absent model and falls back locally. The model is optional because its graph is large and its official release provides PyTorch weights rather than a validated Android ONNX asset.

**Text fidelity:** Real-ESRGAN can invent or change fine letter details despite being a super-resolution network. Neither 70% blending nor the comparison tool guarantees identical text. Inspect every part before export; for strict preservation, set strength to 0% (with a model installed) or use the automatic Lanczos fallback. Large photos and high section counts require time and temporary storage. The comparison's original preview is reduced in resolution, while exports keep their full pixels. Output width is 3840 when input width is below 3840; images already at least 3840 px wide keep their source width, as requested. Aspect ratio is preserved to the nearest pixel.

The app never writes to the selected original URI. Android 10+ exports use MediaStore without storage permission; Android 8–9 request write permission. Sharing uses temporary FileProvider access.
