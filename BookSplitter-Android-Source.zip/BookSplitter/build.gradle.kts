plugins { id("com.android.application") version "9.3.3" apply false; id("org.jetbrains.kotlin.plugin.compose") version "2.2.20" apply false }
